public class myLeapYearCalculator {
//I deleted my main method 
//because i could not figure out how to creat a main method to make codes for all 3 questions work lol.
//I dont even remember how i did this now.
  
// question 2a
  
  public static void printIsLeapYear(int year) {
    
     if ((year % 400 == 0) && (year % 100 == 0)){
        System.out.println(year + " IS a Leap Year");
     }
     
     else if ((year % 100 == 0)){
        System.out.println(year + " Is not a Leap Year");
     }
     
      else if (year % 4 == 0) {
        System.out.println(year + " Is a Leap Year");
     }
    else{ 
    System.out.println(year + " Is NOT a Leap Year");
    }
    
  }

 //question 2b
  public static boolean isLeapYear(int year)
  {
    boolean isLeapYear;
     if ((year % 400 == 0) && (year % 100 == 0)){
     isLeapYear = true;
     }
     
     else if ((year % 100 == 0)){
       isLeapYear = false;
     }
     
      else if (year % 4 == 0) {
        isLeapYear = true;
     }
    else{ 
      isLeapYear = false;
   
    }
     return isLeapYear;
  }
   

// question 2c
    public static int subsequentLeapYear (int year) {
      if (isLeapYear(year) == true) {
        System.out.println(year + "is a leap year!");
        return nextLeapYear (year);
      }
      else {
        return nextLeapYear (year);
      }
    }
      
    public static int nextLeapYear (int year) {
      for (int i = 1; i < 9; i++) {
        int nextYear = year + i;
        if (isLeapYear(nextYear) == true) {
          System.out.println("NEXT leap yr: " + nextYear);
          return nextYear;
        }
      }
      System.out.println ("Sorry, not found");
      return 0;
    }
}

