public class MakingChange {
    public static void main(String[] args) {
       int money = Integer.parseInt(args[0]);   //this was very confusing
       int toonies = 0; 
       int loonies = 0;
       int quarters = 0;
       int dimes = 0;
       int nickels = 0; 
       int pennies = 0;

       int remainder;
        if (money >= 200) {
            remainder = money % 200;
            toonies = money / 200;
            money = remainder;
        }
        if (money >= 100) {
            remainder = money % 100;
            loonies = money / 100;
            money = remainder;
        }
        if (money >= 25) {
          remainder = money % 25;
          quarters = money / 25;
          money = remainder;
        }
        if (money >= 10) {
          remainder = money % 10;
          dimes = money / 10;
          money = remainder;
        }
        if (money >= 5) {
          remainder = money % 5;
          nickels = money / 5;
          money = remainder;
        }
        if (money >= 1) {
          remainder = money % 1;
          pennies = money / 1;
          money = remainder;
        }
        
       System.out.println("Money given is " + money + "Change is ");

       System.out.println("Number of toonies = " + toonies);
       System.out.println("Number of loonies = " + loonies);
       System.out.println("Number of quarters = " + quarters);
       System.out.println("Number of dimes = " + dimes);
       System.out.println("Number of nickels = " + nickels);
       System.out.println("Number of pennies = " + pennies);
    }
//i'm not sure i did this question right

}
